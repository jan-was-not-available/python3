#Activity 3.2.2 Step 7
from Post import Post

all_posts_archive = []

# your code here

username = name
